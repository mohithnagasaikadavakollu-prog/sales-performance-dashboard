
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os

# Ensure reports folder exists
os.makedirs("reports", exist_ok=True)

# Load data
df = pd.read_csv("data/sales_data.csv", parse_dates=["order_date"])

# Compute total revenue column
df["revenue"] = df["quantity"] * df["price"]

# KPI metrics
total_revenue = df["revenue"].sum()
total_orders = df["order_id"].nunique()
avg_order_value = total_revenue / total_orders

print("=== SALES PERFORMANCE REPORT ===")
print(f"Total Revenue: ₹{total_revenue:,.0f}")
print(f"Total Orders: {total_orders}")
print(f"Average Order Value: ₹{avg_order_value:,.2f}\n")

# Revenue by region
rev_region = df.groupby("region")["revenue"].sum().sort_values(ascending=False)
print("Revenue by Region:")
print(rev_region)

# Top product
top_product = df.groupby("product")["revenue"].sum().idxmax()
print(f"\nTop Performing Product: {top_product}\n")

# Plot revenue by region
plt.figure(figsize=(6,4))
rev_region.plot(kind="bar", title="Revenue by Region")
plt.ylabel("Revenue (₹)")
plt.tight_layout()
plt.savefig("reports/revenue_by_region.png")
plt.show()

print("\n✅ Analysis complete. Chart saved in 'reports' folder.")
